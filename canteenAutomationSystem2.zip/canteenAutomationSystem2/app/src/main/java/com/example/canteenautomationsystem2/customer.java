package com.example.canteenautomationsystem2;

public class customer {
    public int id;
    public String name;
    public String number;
    public int cms;
    public String password;
    public String email;

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setCms(int cms) {
        this.cms = cms;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNumber() {
        return number;
    }

    public int getCms() {
        return cms;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }

}
