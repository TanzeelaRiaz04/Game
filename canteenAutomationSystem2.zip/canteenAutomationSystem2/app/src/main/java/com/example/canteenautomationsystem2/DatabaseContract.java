package com.example.canteenautomationsystem2;

import android.provider.BaseColumns;

public class DatabaseContract {
    public DatabaseContract() {}

    /* Inner class that defines the table contents */
    public static abstract class Customer implements BaseColumns {
        public static final String TABLE_NAME = "customers";
        public static final String COL_FULLNAME = "fullname";
        public static final String COL_EMAIL = "email";
        public static final String COL_NUMBER = "phone";
        public static final String COL_CMS = "cms";
        public static final String COL_PASSWORD = "password";
    }



}

