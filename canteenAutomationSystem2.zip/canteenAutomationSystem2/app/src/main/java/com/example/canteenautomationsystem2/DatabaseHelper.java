package com.example.canteenautomationsystem2;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
public class DatabaseHelper extends SQLiteOpenHelper {


    Activity activity;
    SQLiteDatabase database;

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "canteen.db";


    private static final String CREATE_TBL_USERS = "CREATE TABLE "
            + DatabaseContract.Customer.TABLE_NAME + " ("
            + DatabaseContract.Customer._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + DatabaseContract.Customer.COL_FULLNAME + " TEXT NOT NULL, "
            + DatabaseContract.Customer.COL_NUMBER + " NUMERIC,"
            + DatabaseContract.Customer.COL_EMAIL + " TEXT,"
            + DatabaseContract.Customer.COL_CMS + " NUMERIC,"
            + DatabaseContract.Customer.COL_PASSWORD + " TEXT)";





    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL(CREATE_TBL_USERS);
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

}
