package com.example.canteenautomationsystem2;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.canteenautomationsystem.R;

import java.util.ArrayList;
import java.util.List;

public class adminActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    public customer selectedUser;
    List<customer> usersList = new ArrayList<customer>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        fetchAllRecord();
        dbHelper = new DatabaseHelper(this);


    }

    public void fetchAllRecord() {

        DatabaseHelper dbHelper=new DatabaseHelper(getApplicationContext());
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] columns = {
                DatabaseContract.Customer._ID,
                DatabaseContract.Customer.COL_FULLNAME,
                DatabaseContract.Customer.COL_NUMBER,
                DatabaseContract.Customer.COL_CMS,
                DatabaseContract.Customer.COL_PASSWORD,
                DatabaseContract.Customer.COL_EMAIL
        };

        String sortOrder = DatabaseContract.Customer.COL_FULLNAME + " ASC";
        Cursor c = db.query(DatabaseContract.Customer.TABLE_NAME, columns, null, null, null, null, sortOrder);


        while (c.moveToNext()) {
            customer u = new customer();
            u.setId(c.getInt(0));
            u.setName( c.getString(1) );
            u.setNumber(c.getString(2));
            u.setEmail(c.getString( 3));
            u.setCms(c.getInt(4));
            u.setPassword(c.getString(5));
            usersList.add((u));
        }
        c.close();

        final ListView listview=(ListView) findViewById(R.id.viewAll);
        final ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1, usersList);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                selectedUser= usersList.get(position);
                deleteCustomer(selectedUser.getId());

            }
        });
        db.close();
    }

    public void  deleteCustomer(int id)
    {

        SQLiteDatabase db =dbHelper.getWritableDatabase();
        int flag = db.delete(DatabaseContract.Customer.TABLE_NAME, DatabaseContract.Customer._ID +" = "+ id,null);


        if(flag>0)
        {
            Toast.makeText(this,"Record Delete successfully",Toast.LENGTH_SHORT).show();
        }else
        {
            Toast.makeText(this, "Error while deletion", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }


}
