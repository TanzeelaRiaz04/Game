package com.example.canteenautomationsystem2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.canteenautomationsystem.R;
import com.example.canteenautomationsystem2.Rating;

public class Cart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
    }
    public void rating(View view){
        Intent in=new Intent(this, Rating.class);
        startActivity(in);
    }
}
