package com.example.canteenautomationsystem2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.canteenautomationsystem.R;

public class Menu extends AppCompatActivity {
    ListView lst;
    String[] names={"Pizza","Burger","Salad","Biryani","Roll","Fries","Pasta"};
    String[] desc={" Different Flavours Hope u enjoying it","Different Tastes are Available","people Liked it!","Unique Taste","Different Flavour with low prices","Everyone Liked it!","lovely taste with different Sauces"};
Integer[] imgid={R.drawable.pizza,R.drawable.m2,R.drawable.russian,R.drawable.biryani,R.drawable.m3,R.drawable.fries,R.drawable.macrony};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

lst=(ListView)findViewById(R.id.listview);
CustomListview customListView=new CustomListview(this,names,desc,imgid);
lst.setAdapter(customListView);

lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent , View view, int position, long id) {
       // String Templistview=names[position].toString();
        if(position==0)
        {
            Intent appInfo = new Intent(Menu.this, pizza.class);
            startActivity(appInfo);
        }
        else if(position==1)
        {
            Intent appInfo = new Intent(Menu.this, Burger.class);
            startActivity(appInfo);
        }
        else if(position==2)
        {
            Intent appInfo = new Intent(Menu.this, Russian.class);
            startActivity(appInfo);
        }
        else if(position==3)
        {
            Intent appInfo = new Intent(Menu.this, Biryani.class);
            startActivity(appInfo);
        }
        else if(position==4)
        {
            Intent appInfo = new Intent(Menu.this, Roll.class);
            startActivity(appInfo);
        }
        else if(position==5)
        {
            Intent appInfo = new Intent(Menu.this, Fries.class);
            startActivity(appInfo);
        }
        else if(position==6)
        {
            Intent appInfo = new Intent(Menu.this, Macrony.class);
            startActivity(appInfo);
        }

    }
});
    }

}





