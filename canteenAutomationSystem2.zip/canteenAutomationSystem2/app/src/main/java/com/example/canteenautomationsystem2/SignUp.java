package com.example.canteenautomationsystem2;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.canteenautomationsystem.R;

import java.util.regex.Pattern;

public class SignUp extends AppCompatActivity {

    DatabaseHelper dbHelper;
    private TextView alreadyusers;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        dbHelper=new DatabaseHelper(this);
    }


    public void onSignUpClick(View v) {
        if (v.getId() == R.id.button_register) {
            EditText name = (EditText) findViewById(R.id.name);
            EditText contact = (EditText) findViewById(R.id.contact);
            EditText email = (EditText) findViewById(R.id.email);
            EditText cms = (EditText) findViewById(R.id.cms);
            EditText pass1 = (EditText) findViewById(R.id.password);
            EditText pass2 = (EditText) findViewById(R.id.cpassword);

            String namestr = name.getText().toString();
            String contactstr = contact.getText().toString();
            String emailstr = email.getText().toString();
            String cmsstr = cms.getText().toString();
            String pass1str = pass1.getText().toString();
            String pass2str = pass2.getText().toString();
            if (TextUtils.isEmpty(namestr)) {
                name.setError("please enter your name");

            } else if (TextUtils.isEmpty(contactstr)) {
                contact.setError("please enter your contact");
            } else if (!Patterns.PHONE.matcher(contactstr).matches()) {
                contact.setError("hint 0345-5092704");
            } else if (!(contactstr.length()==11))
            {
                contact.setError("hint 0345-5092704");
            } else if (TextUtils.isEmpty(emailstr)) {
                email.setError("please enter email");
            } else if (!Patterns.EMAIL_ADDRESS.matcher(emailstr).matches()) {
                email.setError("hint  tanu@gmail.com");
            } else if (TextUtils.isEmpty(cmsstr)) {
                cms.setError("please enter cms");
            } else if (TextUtils.isEmpty(pass1str)) {
                pass1.setError("please enter password ");
            } else if (TextUtils.isEmpty(pass2str)) {
                pass2.setError("please confirm your password");
            } else if (!pass1str.equals(pass2str)) {
                //popup msg:
                Toast tpass = Toast.makeText(SignUp.this, "passwords don't match", Toast.LENGTH_SHORT);
                tpass.show();

            } else if (checkDublicate(dbHelper,namestr)) {
                    DatabaseHelper dbHelper = new DatabaseHelper(this);
                    SQLiteDatabase db = dbHelper.getWritableDatabase();

                    ContentValues values = new ContentValues();

                    values.put(DatabaseContract.Customer.COL_FULLNAME, name.getText().toString());
                values.put(DatabaseContract.Customer.COL_NUMBER, contact.getText().toString());
                    values.put(DatabaseContract.Customer.COL_EMAIL, email.getText().toString());
                values.put(DatabaseContract.Customer.COL_CMS, cms.getText().toString());
                values.put(DatabaseContract.Customer.COL_PASSWORD, pass1.getText().toString());


                    Long newRowId = db.insert(DatabaseContract.Customer.TABLE_NAME, null, values);
                    if (newRowId > 0) {
                        Toast.makeText(getApplicationContext(), "Congratulation ! Welcome to Menu. " , Toast.LENGTH_SHORT).show();
                        Intent intent=new Intent(SignUp.this, Menu.class);
                        startActivity(intent);


                    }
                    db.close();
                } else {
                    Toast.makeText(getApplicationContext(), "Customer already exist." , Toast.LENGTH_SHORT).show();

                }

            }
        }

    public boolean checkDublicate(DatabaseHelper dbHelper,String userEmail )
    {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String selection=DatabaseContract.Customer.COL_EMAIL +" = ?";
        String[] selectionArgs={userEmail};
        Cursor c = db.query(
                DatabaseContract.Customer.TABLE_NAME,
                new String[]{DatabaseContract.Customer._ID,DatabaseContract.Customer.COL_EMAIL},selection,selectionArgs, null, null, null );

        boolean isExist=false;
        if(c != null)
        {
            isExist=true;
        }
        c.close();
        db.close();

        return isExist;
    }
}


