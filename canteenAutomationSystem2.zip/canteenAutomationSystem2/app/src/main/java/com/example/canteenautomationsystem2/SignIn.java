package com.example.canteenautomationsystem2;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.canteenautomationsystem.R;

public class SignIn extends AppCompatActivity {
    private EditText Name;
    private EditText Password;

    private TextView Info;
    private Button Login;
    private Button Admin;
    private int counter =3;

    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        dbHelper=new DatabaseHelper(this);

        Name = (EditText) findViewById(R.id.etname) ;
        Password = (EditText) findViewById(R.id.etpassword);
        Info = (TextView) findViewById(R.id.tvInfo);
        Login = (Button) findViewById(R.id.btnLogin);
        Admin=(Button) findViewById(R.id.btnAdmin);
        Info.setText("    No of attempts remaining 3:");

      Admin.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Intent intent1=new Intent(SignIn.this,adminActivity.class);
              startActivity(intent1);
          }
      });

        Login.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
//        validate(Name.getText().toString(),Password.getText().toString());


        String name = Name.getText().toString();
        String pass = Password.getText().toString();

        if (TextUtils.isEmpty(name)) {
            Name.setError("Please enter your n.");
        } else if (TextUtils.isEmpty(pass)) {
            Password.setError("Please enter your password");
        } else if(checkUser(dbHelper, name, pass)) {

            Toast.makeText(SignIn.this, "    Login ", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(SignIn.this, Menu.class);

            startActivity(intent);
            }
            else
            {
                Toast.makeText(getApplicationContext(), "User Not found !!!!!!", Toast.LENGTH_SHORT).show();
            }

        }
});

    }

    public boolean checkUser(DatabaseHelper dbHelper, String name, String password) {

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String selection = DatabaseContract.Customer.COL_FULLNAME + " = ?" + " AND " + DatabaseContract.Customer.COL_PASSWORD + " = ?";
        String[] selectionArgs = {name, password};
        Cursor c = db.query(
                DatabaseContract.Customer.TABLE_NAME,
                new String[]{DatabaseContract.Customer._ID, DatabaseContract.Customer.COL_FULLNAME, DatabaseContract.Customer.COL_PASSWORD},
                selection,
                selectionArgs,
                null, null, null);

        boolean isExist = c.moveToFirst();
        c.close();
        db.close();

        return isExist;
    }
   
}



