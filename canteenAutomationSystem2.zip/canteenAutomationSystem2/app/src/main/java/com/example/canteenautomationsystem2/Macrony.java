package com.example.canteenautomationsystem2;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.canteenautomationsystem.R;

import java.util.ArrayList;
import java.util.List;

public class Macrony extends AppCompatActivity {
    private Spinner Spinner1,Spinner2;
    private Button button1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_macrony);
        addItemsOnSpinner2();
        addListenerOnButton();
        addListenerOnSpinnerItemSelection();
    }
    public void addItemsOnSpinner2()
    {
        Spinner2=(Spinner)findViewById(R.id.spinner2);
        List<String> list=new ArrayList<String>();
        list.add("Quantity:01");
        list.add("Quantity:02");
        list.add("Quantity:03");
        list.add("Quantity:04");
        list.add("Quantity:05");
        list.add("Quantity:06");
        ArrayAdapter<String> dataAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        Spinner2.setAdapter(dataAdapter);

    }
    public void addListenerOnSpinnerItemSelection()
    {
        Spinner1=(Spinner)findViewById(R.id.spinner);
        Spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    }
    public void addListenerOnButton()
    {Spinner1=(Spinner)findViewById(R.id.spinner);
        Spinner2=(Spinner)findViewById(R.id.spinner2);
        button1=(Button)findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Toast.makeText(pizza.this, "\nSelected Flavour is:" + String.valueOf(Spinner1.getSelectedItem()) + "\nQuantity of Pizza's is:" + String.valueOf(Spinner2.getSelectedItem()), Toast.LENGTH_SHORT).show();

                AlertDialog.Builder dialog = new AlertDialog.Builder(Macrony.this);
                dialog.setMessage("\nSelected Flavour is:" + String.valueOf(Spinner1.getSelectedItem()) + "\n Number of Pizza's:" + String.valueOf(Spinner2.getSelectedItem()));
                dialog.setPositiveButton("Yes ", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                        Intent intent = new Intent(Macrony.this, Rating.class);
                        startActivity(intent);
//                        setLogin(context,false);
//                        setLoginHelper(context,new HelperModel(-1,"null","null","null","null","null","null"));
//                        // Launching the login activity
//
//                        ((Activity) context).finish();
                    }
                });
                dialog.setNegativeButton("Cancle", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                        // TODO Auto-generated method stub

                    }
                });
                dialog.show();
            }
        });
    }
}
