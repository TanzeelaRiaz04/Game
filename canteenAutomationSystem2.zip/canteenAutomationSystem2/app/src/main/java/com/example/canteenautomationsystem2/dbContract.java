package com.example.canteenautomationsystem2;

import android.provider.BaseColumns;

public class dbContract {

    String name,contact ,email,cms, uname, pass;


    public void setName(String name)
    {
        this.name  = name;
    }
    public String getName()
    {
        return this.name;
    }
    public void setContact(String contact)
    {
        this.contact  = contact;
    }
    public String getContact()
    {
        return this.contact;
    }
    public void setEmail(String email)
    {
        this.email  = email;
    }
    public String getEmail()
    {
        return this.email;
    }
    public void setCms(String cms)
    {
        this.name  = cms;
    }
    public String getCms()
    {
        return this.cms;
    }
    public void setUname(String uname)
    {
        this.uname  = uname;
    }
    public String getUname()
    {
        return this.uname;
    }
    public void setPass(String pass)
    {
        this.pass  = pass;
    }
    public String getPass()
    {
        return this.pass;
    }


    public static abstract class Customer implements BaseColumns {
        public static final String TABLE_NAME = "dbContracts";
        public static final String COL_FULLNAME = "";
        public static final String COL_CONTACT= "contactno";
        public static final String COL_EMAIL = "email";
        public static final String COL_CMS = "cms";
        public static final String COL_PASSWORD = "password";
    }

}