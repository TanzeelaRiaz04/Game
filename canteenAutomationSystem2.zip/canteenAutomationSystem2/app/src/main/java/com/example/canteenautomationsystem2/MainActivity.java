package com.example.canteenautomationsystem2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.canteenautomationsystem2.Menu;
import com.example.canteenautomationsystem.R;
import com.example.canteenautomationsystem2.SignIn;
import com.example.canteenautomationsystem2.SignUp;

public class MainActivity extends AppCompatActivity {
    EditText Name,cms,E_mail,contactNo,password;
    Button button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button = (Button) findViewById(R.id.button);

    }



    public void signIn(View view) {
        Intent intent = new Intent(MainActivity.this, SignIn.class);
        startActivity(intent);
    }

    public void Menu(View view) {
        Intent intent = new Intent(MainActivity.this, Menu.class);
        startActivity(intent);
    }

    public void signup(View view) {
        Intent intent = new Intent(MainActivity.this, SignUp.class);
        startActivity(intent);
    }
}


